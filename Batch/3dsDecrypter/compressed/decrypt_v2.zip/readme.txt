Supports .CIA, .3DS, w/e.

Drop file on decrypt.exe, receive decrypted NCCH(s). Use ctrtool to extract further.

If the game uses seed crypto, it will look first in seeddb.bin for the seed, then check Nintendo's servers. You can acquire an up to date copy of seeddb.bin from http://3ds.titlekeys.gq/
